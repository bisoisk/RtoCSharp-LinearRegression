﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.IO;
using Spearing.Utilities.Data.Frames;
using RDotNet;
using MathNet.Numerics.LinearAlgebra;
using MathNet.Numerics.LinearAlgebra.Complex;
using MathNet.Numerics.LinearAlgebra.Factorization;
using System.Numerics;

namespace Project_3
/// <summary>
/// </summary>
{
    class LinearRegessionInCsharp
    {
            /// <summary>
            /// The main entry point for the application.
            /// </summary>
            static void Main(string[] args)
            {
            //string result;
            //string input;
            ////REngine engine;
            //give the all headers with data type string or Datetime or double
            Frame train_data = Frame.ReadCSV<double, double, double, double, double>(@"F:\DL\SUSANT\DLND\Master\Other\SWISS\Project-3\train_dataset.csv");
            train_data.Print();
            Console.WriteLine("---------------------------------------");
            IEnumerable<Row> headOfTrainData = train_data.Head(1);
            headOfTrainData.Print();
            Console.WriteLine("train_data.csv values are printed");
            Console.WriteLine("---------------------------------------");
            Console.Write("Press any key to print valueY action.");
            Console.ReadLine();
            //Arrange for indivudal matrix..
            List<double> valueY = train_data["Y"].As<double>();
            List<double> valueX1 = train_data["X1"].As<double>();
            List<double> valueX2 = train_data["X2"].As<double>();
            List<double> valueX3 = train_data["X3"].As<double>();
            List<double> valueX4 = train_data["X4"].As<double>();
            Console.WriteLine(valueY);
            Console.WriteLine("---------------------------------------");
            Console.Write("Press any key to print valueX1 action.");
            Console.ReadLine();
            Console.WriteLine(valueX1);
            Console.WriteLine("---------------------------------------");
            Console.Write("Press any key to print valueX2 action.");
            Console.ReadLine();
            Console.WriteLine(valueX2);
            Console.WriteLine("---------------------------------------");
            Console.Write("Press any key to print valueX3 action.");
            Console.ReadLine();
            Console.WriteLine(valueX3);
            Console.WriteLine("---------------------------------------");
            Console.Write("Press any key to print valueX4 action.");
            Console.ReadLine();
            Console.WriteLine(valueX4);
            Console.WriteLine("---------------------------------------");

            
          double[][] design = new double[train_data.Count][];
            int i = 0;
            foreach(Row r in train_data)
            {
                double[] rowArray = new double[r.Values.Length];
                for (int j= 0;j<r.Values.Length;j++)
                {
                    rowArray[j] = double.Parse(r.Values[j].ToString());
                }
                design[i] = rowArray;
                i++;
            }
            Console.WriteLine("\nFinding coefficients using inversion");
            double[] testDesign=Solve(design);
            foreach(double d in testDesign)
            {
                Console.WriteLine(d);
                Console.WriteLine("Done\n");
            }
            Console.WriteLine("Coefficients :\n");
            ShowVector(testDesign, 5);
            Console.WriteLine("");


            Console.ReadLine();
            var envPath = Environment.GetEnvironmentVariable("PATH");
            string s = null;
            if (Environment.Is64BitProcess)
                s = @"C:\Program Files\R\R-3.4.3\bin\x64";
            else
                s = @"C:\Program Files\R\R-3.4.3";
            Environment.SetEnvironmentVariable("PATH", envPath + Path.PathSeparator + s);
            REngine.SetEnvironmentVariables();
            REngine cSharpimplementsR = REngine.GetInstance();
           cSharpimplementsR.Evaluate("inputDoc<-read.csv('F:/DL/SUSANT/DLND/Master/Other/SWISS/Project-3/train_dataset.csv')").AsNumericMatrix();
            //cSharpimplementsR.Evaluate("inputDoc<-read.csv('@"F:\DL\SUSANT\DLND\Master\Other\SWISS\Project-3\train_dataset.csv')");
            //NumericVector fitvalue = cSharpimplementsR.Evaluate("fitvalue <-lm(Y~X1+X2+X3+X4,inputDoc)").AsNumeric();
            NumericMatrix fitValue = cSharpimplementsR.Evaluate("fitValue <- lm(Y~X1+X2+X3+X4,inputDoc)").AsNumericMatrix();
            Console.ReadKey();
           NumericMatrix foreCastvalue =cSharpimplementsR.Evaluate("library(forecast)").AsNumericMatrix();
            cSharpimplementsR.Evaluate("arimaFit <- auto.arima(fitValue)");
            cSharpimplementsR.Evaluate("fCast<-forecast(fitValue)");
            cSharpimplementsR.Evaluate("plot(fCast");
            NumericVector nv = cSharpimplementsR.GetSymbol("fCast").AsNumeric();
            Console.WriteLine("---------------------------------------");
            Console.WriteLine(fitValue);
            Console.WriteLine(foreCastvalue);
            ////
//#region Polymath for Coefficent
//            const int degree = 5;
//            var x1 = valueX1.ToArray();
//            var x2 = valueX2.ToArray();
//            var x3 = valueX3.ToArray();
//            var x4 = valueX4.ToArray();
//            var y = valueY.ToArray();
//            var p = Polyfit(x1, x2, x3, x4, y, degree);
//            foreach (var d in p) Console.Write("{0} ", d);
//            Console.WriteLine();
//            for (int i = 0; i < x1.Length; i++)
//                Console.WriteLine("{0} => {1} diff {2}", x1, Polyval(p, x1[i]), y[i] - Polyval(p, x1[i]));
//            Console.ReadKey(true);
//            ////

//            //////
//            Console.WriteLine("\nFinding coefficients using inversion");
//            double[] coef = Solve(fitValue); // use design matrix
//            Console.WriteLine("Done\n");

//            Console.WriteLine("Coefficients are:\n");
//            ShowVector(coef, 5);
//            Console.WriteLine("");

//#endregion
        }


#region Methods-for-Matrix
        static double[][] Design(double[][] fitValue)
        {
            // add a leading col of 1.0 values
            int rows = fitValue.Length;
            int cols = fitValue[0].Length;
            double[][] result = MatrixCreate(rows, cols + 1);
            for (int i = 0; i < rows; ++i)
                result[i][0] = 1.0;

            for (int i = 0; i < rows; ++i)
                for (int j = 0; j < cols; ++j)
                    result[i][j + 1] = fitValue[i][j];

            return result;
        }


        static double[] Solve(double[][] fitValue)
        {
            // find linear regression coefficients
            // 1. peel off X matrix and Y vector
            int rows = fitValue.Length;
            int cols = fitValue[0].Length;
            double[][] X = MatrixCreate(rows, cols - 1);
            double[][] Y = MatrixCreate(rows, 1); // a column vector

            int j;
            for (int i = 0; i < rows; ++i)
            {
                for (j = 0; j < cols - 1; ++j)
                {
                    X[i][j] = fitValue[i][j];
                }
                Y[i][0] = fitValue[i][j]; // last column
            }

            // 2. B = inv(Xt * X) * Xt * y
            double[][] Xt = MatrixTranspose(X);
            double[][] XtX = MatrixProduct(Xt, X);
            double[][] inv = MatrixInverse(XtX);
            double[][] invXt = MatrixProduct(inv, Xt);

            double[][] mResult = MatrixProduct(invXt, Y);
            double[] result = MatrixToVector(mResult);
            return result;
        } // Solve

        static void ShowVector(double[] v, int dec)
        {
            for (int i = 0; i < v.Length; ++i)
                Console.Write(v[i].ToString("F" + dec) + "  ");
            Console.WriteLine("");
        }


        // ===== Matrix routines

        static double[][] MatrixCreate(int rows, int cols)
        {
            // allocates/creates a matrix initialized to all 0.0
            // do error checking here
            double[][] result = new double[rows][];
            for (int i = 0; i < rows; ++i)
                result[i] = new double[cols];
            return result;
        }

        // -------------------------------------------------------------
        static double[][] MatrixTranspose(double[][] matrix)
        {
            int rows = matrix.Length;
            int cols = matrix[0].Length;
            double[][] result = MatrixCreate(cols, rows); // note indexing
            for (int i = 0; i < rows; ++i)
            {
                for (int j = 0; j < cols; ++j)
                {
                    result[j][i] = matrix[i][j];
                }
            }
            return result;
        } // TransposeMatrix

        static double[][] MatrixProduct(double[][] matrixA, double[][] matrixB)
        {
            int aRows = matrixA.Length; int aCols = matrixA[0].Length;
            int bRows = matrixB.Length; int bCols = matrixB[0].Length;
            if (aCols != bRows)
                throw new Exception("Non-conformable matrices in MatrixProduct");

            double[][] result = MatrixCreate(aRows, bCols);

            for (int i = 0; i < aRows; ++i) // each row of A
                for (int j = 0; j < bCols; ++j) // each col of B
                    for (int k = 0; k < aCols; ++k) // could use k < bRows
                        result[i][j] += matrixA[i][k] * matrixB[k][j];

            //Parallel.For(0, aRows, i =>
            //  {
            //    for (int j = 0; j < bCols; ++j) // each col of B
            //      for (int k = 0; k < aCols; ++k) // could use k < bRows
            //        result[i][j] += matrixA[i][k] * matrixB[k][j];
            //  }
            //);

            return result;
        }

        static double[][] MatrixInverse(double[][] matrix)
        {
            int n = matrix.Length;
            double[][] result = MatrixDuplicate(matrix);

            int[] perm;
            int toggle;
            double[][] lum = MatrixDecompose(matrix, out perm, out toggle);
            if (lum == null)
                throw new Exception("Unable to compute inverse");

            double[] b = new double[n];
            for (int i = 0; i < n; ++i)
            {
                for (int j = 0; j < n; ++j)
                {
                    if (i == perm[j])
                        b[j] = 1.0;
                    else
                        b[j] = 0.0;
                }

                double[] x = HelperSolve(lum, b); // use decomposition

                for (int j = 0; j < n; ++j)
                    result[j][i] = x[j];
            }
            return result;
        }

        static double MatrixDeterminant(double[][] matrix)
        {
            int[] perm;
            int toggle;
            double[][] lum = MatrixDecompose(matrix, out perm, out toggle);
            if (lum == null)
                throw new Exception("Unable to compute MatrixDeterminant");
            double result = toggle;
            for (int i = 0; i < lum.Length; ++i)
                result *= lum[i][i];
            return result;
        }

        static double[] MatrixToVector(double[][] matrix)
        {
            // single column matrix to vector
            int rows = matrix.Length;
            int cols = matrix[0].Length;
            if (cols != 1)
                throw new Exception("Bad matrix");
            double[] result = new double[rows];
            for (int i = 0; i < rows; ++i)
                result[i] = matrix[i][0];
            return result;
        }

        static double[][] MatrixDecompose(double[][] matrix, out int[] perm,
  out int toggle)
        {
            // Doolittle LUP decomposition with partial pivoting.
            // returns: result is L (with 1s on diagonal) and U;
            // perm holds row permutations; toggle is +1 or -1 (even or odd)
            int rows = matrix.Length;
            int cols = matrix[0].Length;
            if (rows != cols)
                throw new Exception("Non-square mattrix");

            int n = rows; // convenience

            double[][] result = MatrixDuplicate(matrix); // 

            perm = new int[n]; // set up row permutation result
            for (int i = 0; i < n; ++i) { perm[i] = i; }

            toggle = 1; // toggle tracks row swaps

            for (int j = 0; j < n - 1; ++j) // each column
            {
                double colMax = Math.Abs(result[j][j]);
                int pRow = j;
                //for (int i = j + 1; i < n; ++i) // deprecated
                //{
                //  if (result[i][j] > colMax)
                //  {
                //    colMax = result[i][j];
                //    pRow = i;
                //  }
                //}

                for (int i = j + 1; i < n; ++i) // reader Matt V needed this:
                {
                    if (Math.Abs(result[i][j]) > colMax)
                    {
                        colMax = Math.Abs(result[i][j]);
                        pRow = i;
                    }
                }
                // Not sure if this approach is needed always, or not.

                if (pRow != j) // if largest value not on pivot, swap rows
                {
                    double[] rowPtr = result[pRow];
                    result[pRow] = result[j];
                    result[j] = rowPtr;

                    int tmp = perm[pRow]; // and swap perm info
                    perm[pRow] = perm[j];
                    perm[j] = tmp;

                    toggle = -toggle; // adjust the row-swap toggle
                }

                // -------------------------------------------------------------
                // This part added later (not in original code) 
                // and replaces the 'return null' below.
                // if there is a 0 on the diagonal, find a good row 
                // from i = j+1 down that doesn't have
                // a 0 in column j, and swap that good row with row j

                if (result[j][j] == 0.0)
                {
                    // find a good row to swap
                    int goodRow = -1;
                    for (int row = j + 1; row < n; ++row)
                    {
                        if (result[row][j] != 0.0)
                            goodRow = row;
                    }

                    if (goodRow == -1)
                        throw new Exception("Cannot use Doolittle's method");

                    // swap rows so 0.0 no longer on diagonal
                    double[] rowPtr = result[goodRow];
                    result[goodRow] = result[j];
                    result[j] = rowPtr;

                    int tmp = perm[goodRow]; // and swap perm info
                    perm[goodRow] = perm[j];
                    perm[j] = tmp;

                    toggle = -toggle; // adjust the row-swap toggle
                }
                // -------------------------------------------------------------

                //if (Math.Abs(result[j][j]) < 1.0E-20) // deprecated
                //  return null; // consider a throw

                for (int i = j + 1; i < n; ++i)
                {
                    result[i][j] /= result[j][j];
                    for (int k = j + 1; k < n; ++k)
                    {
                        result[i][k] -= result[i][j] * result[j][k];
                    }
                }

            } // main j column loop

            return result;
        } // MatrixDecompose
        // -------------------------------------------------------------

        static double[] HelperSolve(double[][] luMatrix, double[] b)
        {
            // before calling this helper, permute b using the perm array
            // from MatrixDecompose that generated luMatrix
            int n = luMatrix.Length;
            double[] x = new double[n];
            b.CopyTo(x, 0);

            for (int i = 1; i < n; ++i)
            {
                double sum = x[i];
                for (int j = 0; j < i; ++j)
                    sum -= luMatrix[i][j] * x[j];
                x[i] = sum;
            }

            x[n - 1] /= luMatrix[n - 1][n - 1];
            for (int i = n - 2; i >= 0; --i)
            {
                double sum = x[i];
                for (int j = i + 1; j < n; ++j)
                    sum -= luMatrix[i][j] * x[j];
                x[i] = sum / luMatrix[i][i];
            }

            return x;
        }

        // -------------------------------------------------------------

        //static double[] SystemSolve(double[][] A, double[] b)
        //{
        //  // Solve Ax = b
        //  int n = A.Length;

        //  // 1. decompose A
        //  int[] perm;
        //  int toggle;
        //  double[][] luMatrix = MatrixDecompose(A, out perm, out toggle);
        //  if (luMatrix == null)
        //    return null;

        //  // 2. permute b according to perm[] into bp
        //  double[] bp = new double[b.Length];
        //  for (int i = 0; i < n; ++i)
        //    bp[i] = b[perm[i]];

        //  // 3. call helper
        //  double[] x = HelperSolve(luMatrix, bp);
        //  return x;
        //} // SystemSolve

        // -------------------------------------------------------------

        static double[][] MatrixDuplicate(double[][] matrix)
        {
            // allocates/creates a duplicate of a matrix
            double[][] result = MatrixCreate(matrix.Length, matrix[0].Length);
            for (int i = 0; i < matrix.Length; ++i) // copy the values
                for (int j = 0; j < matrix[i].Length; ++j)
                    result[i][j] = matrix[i][j];
            return result;
        }

        // -------------------------------------------------------------

        static double[][] ExtractLower(double[][] matrix)
        {
            // lower part of a Doolittle decomp (1.0s on diagonal, 0.0s in upper)
            int rows = matrix.Length; int cols = matrix[0].Length;
            double[][] result = MatrixCreate(rows, cols);
            for (int i = 0; i < rows; ++i)
            {
                for (int j = 0; j < cols; ++j)
                {
                    if (i == j)
                        result[i][j] = 1.0;
                    else if (i > j)
                        result[i][j] = matrix[i][j];
                }
            }
            return result;
        }

        static double[][] ExtractUpper(double[][] matrix)
        {
            // upper part of a Doolittle decomp (0.0s in the strictly lower part)
            int rows = matrix.Length; int cols = matrix[0].Length;
            double[][] result = MatrixCreate(rows, cols);
            for (int i = 0; i < rows; ++i)
            {
                for (int j = 0; j < cols; ++j)
                {
                    if (i <= j)
                        result[i][j] = matrix[i][j];
                }
            }
            return result;
        }

        // -------------------------------------------------------------

        static double[][] PermArrayToMatrix(int[] perm)
        {
            // convert Doolittle perm array to corresponding perm matrix
            int n = perm.Length;
            double[][] result = MatrixCreate(n, n);
            for (int i = 0; i < n; ++i)
                result[i][perm[i]] = 1.0;
            return result;
        }

        static double[][] UnPermute(double[][] luProduct, int[] perm)
        {
            // unpermute product of Doolittle lower * upper matrix according to perm[]
            // no real use except to demo LU decomposition, or for consistency testing
            double[][] result = MatrixDuplicate(luProduct);

            int[] unperm = new int[perm.Length];
            for (int i = 0; i < perm.Length; ++i)
                unperm[perm[i]] = i;

            for (int r = 0; r < luProduct.Length; ++r)
                result[r] = luProduct[unperm[r]];

            return result;
        } // UnPermute
          // -------------------------------------------------------------

        #endregion

//#region polymath method
//        public static double[] Polyfit(double[] valueX1, double[] valueX2, double[] valueX3, double[] valueX4, double[] valueY, int degree)
//        {
//            // Vandermonde matrix
//            var v = new DenseMatrix(valueX1.Length, degree + 1);
//            for (int i = 0; i < v.RowCount; i++)
//                for (int j = 0; j <= degree; j++) v[i, j] = Math.Pow(valueX1[i], j);
//            var yv = new DenseVector(5).ToColumnMatrix();
//            QR<Complex> qr = v.QR();
//            // Math.Net doesn't have an "economy" QR, so:
//            // cut R short to square upper triangle, then recompute Q
//            var r = qr.R.SubMatrix(0, degree + 1, 0, degree + 1);
//            var q = v.Multiply(r.Inverse());
//            var p = r.Inverse().Multiply(q.TransposeThisAndMultiply(yv));
//            return p.Column(0).ToArray();
//#endregion
        }
    }

